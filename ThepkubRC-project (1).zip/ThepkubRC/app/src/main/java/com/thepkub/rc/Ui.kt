package com.thepkub.rc

import android.annotation.SuppressLint
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

val Bg = Color(0xFF0A0E17)
val Panel = Color(0xFF131A29)
val Cyan = Color(0xFF00E5FF)
val Pink = Color(0xFFFF2E93)
val Green = Color(0xFF00E676)
val Dim = Color(0xFF7E8AA3)

@Composable
fun RcTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, background = Bg, surface = Panel, onSurface = Color.White,
            onPrimary = Color.Black, secondary = Pink
        ),
        content = content
    )
}

@SuppressLint("MissingPermission")
@Composable
fun ConnectScreen(vm: AppModel, permVer: Int) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val st by vm.link.state.collectAsState()
    val devices = remember(permVer, refresh, st) { vm.link.paired() }
    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("THEPKUB RC", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { refresh++ }) { Text("รีเฟรช") }
            TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }) { Text("จับคู่บลูทูธ") }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            when (st) {
                LinkState.CONNECTING -> "กำลังเชื่อมต่อ…"
                LinkState.FAILED -> "เชื่อมต่อไม่สำเร็จ — เช็คว่า ESP32 เปิดอยู่และไม่ได้ต่อกับเครื่องอื่น"
                else -> "เลือกอุปกรณ์ที่จับคู่แล้ว (ชื่อ RC-Car)"
            },
            color = if (st == LinkState.FAILED) Pink else Dim
        )
        Spacer(Modifier.height(12.dp))
        if (devices.isEmpty()) {
            Text("ยังไม่พบอุปกรณ์ — ไปจับคู่ \"RC-Car\" ในตั้งค่าบลูทูธก่อน (PIN 1234 หรือ 0000 ถ้าถาม)", color = Dim)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(devices) { d ->
                val isCar = d.name == "RC-Car"
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel)
                        .border(1.dp, if (isCar) Cyan else Color(0xFF222B40), RoundedCornerShape(16.dp))
                        .clickable { vm.link.connect(d) }.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (isCar) "🚗" else "📶", fontSize = 26.sp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(d.name ?: "ไม่ทราบชื่อ", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(d.address, color = Dim, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun DriveScreen(vm: AppModel) {
    var showSet by remember { mutableStateOf(false) }
    val name by vm.link.name.collectAsState()
    Row(
        Modifier.fillMaxSize().background(Bg).systemBarsPadding().padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
            Joystick(Modifier.fillMaxHeight(0.92f).aspectRatio(1f)) { x, y -> vm.joy(x, y) }
        }
        Column(Modifier.weight(1.5f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(Green))
                Spacer(Modifier.width(8.dp))
                Text(name, color = Green, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                OutlinedButton(onClick = { showSet = true }) { Text("⚙ ตั้งค่า") }
            }
            Column(
                Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    if (vm.running) "กำลังทำงาน ${vm.active + 1}/${vm.plan.size}" else if (vm.listening) "🎙 กำลังฟังต่อเนื่อง" else "แตะไมค์เพื่อสั่งด้วยเสียง",
                    color = if (vm.running) Cyan else Dim, fontSize = 13.sp
                )
                Text(vm.heard.ifEmpty { "ลองพูด: ตรงไปข้างหน้า 2 วินาที แล้วเลี้ยวซ้าย 0.5 วินาที แล้วเลี้ยวขวา 90 องศา" },
                    fontSize = 16.sp, maxLines = 3)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vm.plan.size) { i ->
                        val on = vm.running && i == vm.active
                        Text(
                            vm.plan[i].label(),
                            Modifier.clip(RoundedCornerShape(10.dp))
                                .background(if (on) Cyan else Color(0xFF1E2A44)).padding(horizontal = 12.dp, vertical = 6.dp),
                            color = if (on) Color.Black else Color.White, fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ความเร็ว ${vm.speed}%", Modifier.width(110.dp), fontWeight = FontWeight.Bold)
                Slider(value = vm.speed.toFloat(), onValueChange = { vm.changeSpeed(it.toInt()) }, valueRange = 20f..100f)
            }
        }
        Column(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally) {
            MicButton(vm.listening) { vm.toggleListening() }
            Box(
                Modifier.size(92.dp).clip(CircleShape).background(Pink).clickable { vm.estop() },
                contentAlignment = Alignment.Center
            ) { Text("STOP", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp) }
        }
    }
    if (showSet) SettingsDialog(vm) { showSet = false }
}

@Composable
fun MicButton(on: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(1f, 1.15f, infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    Box(
        Modifier.size(104.dp)
            .graphicsLayer { val k = if (on) s else 1f; scaleX = k; scaleY = k }
            .clip(CircleShape)
            .background(Brush.radialGradient(if (on) listOf(Pink, Color(0xFF8A1550)) else listOf(Color(0xFF22304F), Panel)))
            .border(2.dp, if (on) Pink else Cyan, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text("🎤", fontSize = 40.sp) }
}

@Composable
fun Joystick(modifier: Modifier, onMove: (Float, Float) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    val cb by rememberUpdatedState(onMove)
    Canvas(
        modifier.pointerInput(Unit) {
            val sz = size
            awaitEachGesture {
                val down = awaitFirstDown()
                fun upd(p: Offset) {
                    val r = sz.width / 2f * 0.65f
                    var v = (p - Offset(sz.width / 2f, sz.height / 2f)) / r
                    val len = v.getDistance()
                    if (len > 1f) v /= len
                    knob = v
                    cb(if (abs(v.x) < 0.08f) 0f else v.x, if (abs(v.y) < 0.08f) 0f else -v.y)
                }
                upd(down.position)
                var pressed = true
                while (pressed) {
                    val e = awaitPointerEvent()
                    val c = e.changes.firstOrNull { it.id == down.id }
                    if (c == null || !c.pressed) pressed = false else { upd(c.position); c.consume() }
                }
                knob = Offset.Zero
                cb(0f, 0f)
            }
        }
    ) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(brush = Brush.radialGradient(listOf(Color(0xFF1B2640), Color(0xFF0C1220)), c, r), radius = r, center = c)
        drawCircle(color = Cyan.copy(alpha = 0.35f), radius = r - 2f, center = c, style = Stroke(3f))
        drawCircle(color = Cyan.copy(alpha = 0.15f), radius = r * 0.65f, center = c, style = Stroke(2f))
        val k = c + knob * (r * 0.65f)
        drawCircle(brush = Brush.radialGradient(listOf(Cyan.copy(alpha = 0.45f), Color.Transparent), k, r * 0.55f), radius = r * 0.55f, center = k)
        drawCircle(brush = Brush.radialGradient(listOf(Color(0xFF9CF6FF), Cyan), k, r * 0.3f), radius = r * 0.3f, center = k)
    }
}

@Composable
fun SettingsDialog(vm: AppModel, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("ปิด") } },
        dismissButton = { TextButton(onClick = { vm.estop(); vm.link.disconnect(); onClose() }) { Text("ตัดการเชื่อมต่อ", color = Pink) } },
        title = { Text("ตั้งค่า") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("กลับทิศมอเตอร์ซ้าย", Modifier.weight(1f))
                        Switch(vm.invL, { vm.setInv(it, vm.invR) })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("กลับทิศมอเตอร์ขวา", Modifier.weight(1f))
                        Switch(vm.invR, { vm.setInv(vm.invL, it) })
                    }
                    Text("ทดสอบมอเตอร์ (1,3=ซ้าย / 2,4=ขวา)", color = Dim, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (n in 1..4) OutlinedButton(onClick = { vm.test(n) }, contentPadding = PaddingValues(0.dp), modifier = Modifier.weight(1f)) { Text("M$n") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("ความเร็วหมุน ${vm.dps.toInt()}°/วินาที (ใช้กับ \"เลี้ยว 90 องศา\")", fontSize = 13.sp)
                    Text("ถ้าสั่งเลี้ยว 90° แล้วหมุนเกิน ให้เพิ่มค่า ถ้าหมุนไม่ถึง ให้ลดค่า", color = Dim, fontSize = 11.sp)
                    Slider(value = vm.dps, onValueChange = { vm.changeDps(it) }, valueRange = 60f..500f)
                }
            }
        }
    )
}
