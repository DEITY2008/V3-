package com.thepkub.rc

enum class Kind { FWD, BACK, LEFT, RIGHT, STOP, SPEED }

data class Cmd(val kind: Kind, val value: Double?, val deg: Boolean) {
    private fun num(): String = value?.let { if (it % 1.0 == 0.0) it.toInt().toString() else "%.1f".format(it) } ?: ""
    fun label(): String = when (kind) {
        Kind.FWD -> "↑ ${num().ifEmpty { "1" }}s"
        Kind.BACK -> "↓ ${num().ifEmpty { "1" }}s"
        Kind.LEFT -> "↶ " + if (deg || value == null) "${num().ifEmpty { "90" }}°" else "${num()}s"
        Kind.RIGHT -> "↷ " + if (deg || value == null) "${num().ifEmpty { "90" }}°" else "${num()}s"
        Kind.STOP -> if (value == null) "■ STOP" else "■ ${num()}s"
        Kind.SPEED -> "⚡ ${num()}%"
    }
    fun lcd(): String = when (kind) {
        Kind.FWD -> "FWD ${num().ifEmpty { "1" }}s"
        Kind.BACK -> "BACK ${num().ifEmpty { "1" }}s"
        Kind.LEFT -> "LEFT " + if (deg || value == null) "${num().ifEmpty { "90" }}d" else "${num()}s"
        Kind.RIGHT -> "RIGHT " + if (deg || value == null) "${num().ifEmpty { "90" }}d" else "${num()}s"
        Kind.STOP -> "STOP"
        Kind.SPEED -> "SPEED ${num()}"
    }
}

/** แปลงประโยคเสียง เช่น "ตรงไปข้างหน้า 2 วินาที แล้วเลี้ยวซ้าย 0.5 วินาที แล้วเลี้ยวขวา" เป็นลำดับคำสั่ง */
object VoiceParser {
    private val words = listOf(
        "ศูนย์" to "0", "หนึ่ง" to "1", "สอง" to "2", "สาม" to "3", "สี่" to "4", "ห้า" to "5",
        "หก" to "6", "เจ็ด" to "7", "แปด" to "8", "เก้า" to "9", "สิบ" to "10"
    )
    private val rx = Regex(
        "(ตรงไปข้างหน้า|ไปข้างหน้า|เดินหน้า|วิ่งตรง|ตรงไป|ข้างหน้า|ไปหน้า|ตรง|forward|" +
        "ถอยหลัง|ถอย|หลัง|reverse|back|" +
        "เลี้ยวซ้าย|เลี้ยวไปซ้าย|หมุนซ้าย|ไปซ้าย|ซ้าย|left|" +
        "เลี้ยวขวา|เลี้ยวไปขวา|หมุนขวา|ไปขวา|ขวา|right|" +
        "หยุด|จอด|stop|ความเร็ว|speed)" +
        "\\s*(?:(?:ไป|เป็น|ที่)\\s*)?(\\d+(?:\\.\\d+)?)?\\s*" +
        "(วินาที|วิน|วิ|seconds?|secs?|องศา|degrees?|°)?"
    )

    fun normalize(t: String): String {
        var s = t.lowercase()
        "๐๑๒๓๔๕๖๗๘๙".forEachIndexed { i, c -> s = s.replace(c, ('0' + i)) }
        s = s.replace("ครึ่ง", " 0.5 ").replace("จุด", ".")
        for ((w, d) in words) s = s.replace(w, " $d ")
        s = s.replace(Regex("(\\d)\\s*[.,]\\s*(\\d)"), "$1.$2")
        s = s.replace(Regex("(?<![\\d])\\.\\s*(\\d)"), " 0.$1")
        return s
    }

    private fun kindOf(s: String): Kind = when {
        s.contains("ซ้าย") || s == "left" -> Kind.LEFT
        s.contains("ขวา") || s == "right" -> Kind.RIGHT
        s.contains("ถอย") || s.contains("หลัง") || s == "back" || s == "reverse" -> Kind.BACK
        s.contains("หยุด") || s.contains("จอด") || s == "stop" -> Kind.STOP
        s.contains("ความเร็ว") || s == "speed" -> Kind.SPEED
        else -> Kind.FWD
    }

    fun parse(raw: String): List<Cmd> = rx.findAll(normalize(raw)).map { m ->
        val k = kindOf(m.groupValues[1])
        val n = m.groupValues[2].toDoubleOrNull()
        val u = m.groupValues[3]
        val turn = k == Kind.LEFT || k == Kind.RIGHT
        val deg = turn && (u.startsWith("องศา") || u.startsWith("deg") || u == "°" || (u.isEmpty() && n != null && n > 10))
        Cmd(k, n?.coerceAtMost(if (deg) 720.0 else 30.0), deg)
    }.toList()
}
